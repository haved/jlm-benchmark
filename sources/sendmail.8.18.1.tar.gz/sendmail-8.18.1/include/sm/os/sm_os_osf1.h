/*
 * Copyright (c) 2001 Proofpoint, Inc. and its suppliers.
 *	All rights reserved.
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file which can be found at the top level of
 * the sendmail distribution.
 *
 *	$Id: sm_os_osf1.h,v 1.4 2013-11-22 20:51:34 ca Exp $
 */

/*
**  platform definitions for Digital UNIX
*/

#define SM_OS_NAME "osf1"

#define SM_CONF_SETITIMER 0
