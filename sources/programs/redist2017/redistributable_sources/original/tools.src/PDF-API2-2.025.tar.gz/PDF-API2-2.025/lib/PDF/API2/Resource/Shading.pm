package PDF::API2::Resource::Shading;

our $VERSION = '2.025'; # VERSION

use base 'PDF::API2::Resource';

use strict;
use warnings;

1;
